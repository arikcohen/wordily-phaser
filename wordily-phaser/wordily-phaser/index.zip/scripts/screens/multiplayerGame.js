var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Wordily;
(function (Wordily) {
    var MultiplayerScreen = /** @class */ (function (_super) {
        __extends(MultiplayerScreen, _super);
        function MultiplayerScreen() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        MultiplayerScreen.prototype.init = function (contextId) {
            var _this = this;
            console.log("initiailizing board for context [" + contextId + "]");
            this.board = new MultiplayerBoard(contextId);
            FBInstant.context.getPlayersAsync()
                .then(function (players) {
                _this.updatePlayers(players);
            })
                .catch(function (error) {
                console.log("error getting players: " + error);
            });
        };
        MultiplayerScreen.prototype.create = function () {
            this.background = this.add.tileSprite(0, 0, this.world.width, this.world.height, 'background');
        };
        MultiplayerScreen.prototype.updatePlayers = function (players) {
            console.log("got " + players.length + " players for context " + this.board.gameId);
            for (var i = 0; i < players.length; i++) {
                console.log(players[i].getID() + " " + players[i].getName());
            }
        };
        return MultiplayerScreen;
    }(Phaser.State));
    Wordily.MultiplayerScreen = MultiplayerScreen;
    var MultiplayerBoard = /** @class */ (function () {
        function MultiplayerBoard(gameId) {
            this.isGameStarted = false;
            this.gameId = gameId;
            this.gameDeck = Wordily.Deck.CreateDeck(true, gameId, false, 0, 'deck-full');
        }
        MultiplayerBoard.prototype.toString = function () {
            return JSON.stringify(this);
        };
        return MultiplayerBoard;
    }());
    var MultiplayerPlayer = /** @class */ (function () {
        function MultiplayerPlayer() {
            this.cardsInHand = [];
            this.localHand = [];
        }
        return MultiplayerPlayer;
    }());
})(Wordily || (Wordily = {}));
//# sourceMappingURL=multiplayerGame.js.map